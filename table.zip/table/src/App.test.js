import { render } from "@testing-library/react";
import App from "./App";

test("renders table with 5 records", () => {
  const { container } = render(<App />);
  expect(container.querySelectorAll("tbody>tr").length).toBe(5);
});

test("renders table with 2 records selected", () => {
  const { container } = render(<App />);
  expect(container.querySelectorAll("tbody>tr>td>input[checked]").length).toBe(
    2
  );
});

test("renders table with green icon for records with status=`available`", () => {
  const { container } = render(<App />);
  expect(
    container.querySelectorAll("tbody td span[class='green-dot']").length
  ).toBe(2);
});
