import "./App.css";
import { useState } from "react";
import HeaderActions from "./table/HeaderActions";
import Table from "./table/Table";

const data = [
  {
    id: "101",
    name: "smss.exe",
    device: "Stark",
    path: "\\Device\\HarddiskVolume2\\Windows\\System32\\smss.exe",
    status: "scheduled",
  },

  {
    id: "102",
    name: "netsh.exe",
    device: "Targaryen",
    path: "\\Device\\HarddiskVolume2\\Windows\\System32\\netsh.exe",
    status: "available",
  },

  {
    id: "103",
    name: "uxtheme.dll",
    device: "Lanniester",
    path: "\\Device\\HarddiskVolume1\\Windows\\System32\\uxtheme.dll",
    status: "available",
  },

  {
    id: "104",
    name: "cryptbase.dll",
    device: "Martell",
    path: "\\Device\\HarddiskVolume1\\Windows\\System32\\cryptbase.dll",
    status: "scheduled",
  },

  {
    id: "105",
    name: "7za.exe",
    device: "Baratheon",
    path: "\\Device\\HarddiskVolume1\\temp\\7za.exe",
    status: "scheduled",
  },
];
const columns = [
  {
    title: "Name",
    dataIndex: "name",
    key: "name",
  },
  {
    title: "Device",
    dataIndex: "device",
    key: "device",
  },
  {
    title: "Path",
    dataIndex: "path",
    key: "path",
  },
  {
    title: "Status",
    dataIndex: "status",
    key: "status",
    render: (text, record) => {
      const { status } = record;
      if (status === "available") {
        return (
          <div className="pull-left">
            <span className="green-dot"></span>
            {status}
          </div>
        );
      }
      return text;
    },
  },
];

function FileList() {
  const [selectedIds, setSelectedIds] = useState(["102", "103"]);

  const handleCheckboxClick = (recordId) => {
    const set = new Set(selectedIds);
    if (set.has(recordId)) {
      set.delete(recordId);
    } else {
      set.add(recordId);
    }
    setSelectedIds([...set]);
  };

  const handleDownload = () => {
    const label = data
      .filter((record) => selectedIds.includes(record.id))
      .map((record) => `${record.device} - ${record.path}`);
    alert(label.join(`\n`));
  };

  const handleSelectAll = () => {
    const totalSelectableIds = data
      .filter((record) => record.status === "available")
      .map((record) => record.id);
    setSelectedIds(totalSelectableIds);
  };

  const handleSelectNone = () => {
    setSelectedIds([]);
  };

  return (
    <>
      <div className="mx-15">
        <HeaderActions
          onSelectAll={handleSelectAll}
          onSelectNone={handleSelectNone}
          selectedIdsLength={selectedIds.length}
          totalRecordsLength={data.length}
          onDownload={handleDownload}
        />
      </div>
      <Table
        checkboxProps={(record) => ({
          name: record.name,
          onChange: () => handleCheckboxClick(record.id),
          disabled: record.status !== "available",
        })}
        selectedIds={selectedIds}
        className="w-100"
        data={data}
        columns={columns}
      />
    </>
  );
}

function App() {
  return <FileList />;
}

export default App;
