/**
 * column = {
 *     title: "Name",
 *     dataIndex: "name",
 *     key: "name",
 * }
 * @param columns
 */
export default function TableHeader({ columns }) {
  return (
    <thead>
      <tr>
        <th key="checkbox"></th>
        {columns.map((column) => (
          <th className="capitalize" key={column.key}>
            {column.title}
          </th>
        ))}
      </tr>
    </thead>
  );
}
