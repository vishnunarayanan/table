/**
 * column = {
 *     title: "Name",
 *     dataIndex: "name",
 *     key: "name",
 * }
 *
 * data = {
 *     name: "7za.exe",
 *     device: "Baratheon",
 *     path: "\\Device\\HarddiskVolume1\\temp\\7za.exe",
 *     status: "scheduled",
 *   }
 * @param columns
 * @param data
 */
const renderCell = (record, column) => {
  const defaultText = record[column.dataIndex];
  if (column.render) return column.render(defaultText, record);
  return defaultText;
};

export default function TableBody({
  columns,
  data,
  selectedIds,
  checkboxProps,
}) {
  return (
    <tbody>
      {data.map((record) => {
        const isRecordSelected = selectedIds.includes(record.id);
        return (
          <tr key={record.id} className={isRecordSelected ? "selected" : ""}>
            <td>
              <input
                type="checkbox"
                checked={isRecordSelected}
                {...(checkboxProps && checkboxProps(record))}
              />
            </td>
            {columns.map((column, idx) => (
              <td key={idx} className="capitalize">
                {renderCell(record, column)}
              </td>
            ))}
          </tr>
        );
      })}
    </tbody>
  );
}
