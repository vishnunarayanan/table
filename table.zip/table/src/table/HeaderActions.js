import { useEffect, useRef } from "react";

export default function HeaderActions({
  selectedIdsLength,
  totalRecordsLength,
  onSelectAll,
  onSelectNone,
  onDownload,
}) {
  const checkboxRef = useRef(null);
  const handleCheckboxSelect = (e) => {
    if (e.target.checked) onSelectAll();
    else onSelectNone();
  };

  useEffect(() => {
    if (selectedIdsLength === 0) {
      checkboxRef.current.indeterminate = false;
      checkboxRef.current.checked = false;
      return;
    }
    checkboxRef.current.checked = true;
    if (selectedIdsLength < totalRecordsLength) {
      checkboxRef.current.indeterminate = true;
    }
    if (selectedIdsLength === totalRecordsLength) {
      checkboxRef.current.indeterminate = false;
    }
  }, [selectedIdsLength, totalRecordsLength]);

  return (
    <>
      <input
        type="checkbox"
        onChange={handleCheckboxSelect}
        ref={checkboxRef}
      />
      <span className="ml-15">
        {selectedIdsLength === 0
          ? "None Selected"
          : `Selected ${selectedIdsLength}`}
      </span>
      <button
        className="ml-15"
        disabled={selectedIdsLength === 0}
        onClick={onDownload}
      >
        Download Selected
      </button>
    </>
  );
}
