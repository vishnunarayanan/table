import TableHeader from "./TableHeader";
import TableBody from "./TableBody";

export default function Table({ columns, data, selectedIds, checkboxProps }) {
  return (
    <table className="w-100 table">
      <TableHeader columns={columns} />
      <TableBody
        columns={columns}
        data={data}
        selectedIds={selectedIds}
        checkboxProps={checkboxProps}
      />
    </table>
  );
}
