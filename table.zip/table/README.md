# Steps
1.`yarn install`
2.`yarn start`
3.hit `http://localhost:3000`



## Assumptions made
1.) I have added keys(ID) to the data list
2.) only records having status as "available" are clickable
